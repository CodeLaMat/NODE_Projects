'use strict';

const Datastorage = require('./storage/dataStorageLayer');

const storage=new Datastorage();
