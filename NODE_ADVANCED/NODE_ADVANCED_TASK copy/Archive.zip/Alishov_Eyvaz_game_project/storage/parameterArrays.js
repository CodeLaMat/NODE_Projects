"use strict";

const toInsertArray = (game) => [
  +game.number,
  game.name,
  game.rating,
  game.year,
  +game.quantity,
];

const toUpdateArray = (game) => [
  game.name,
  game.rating,
  game.year,
  +game.quantity,
  +game.number,
];

module.exports = { toInsertArray, toUpdateArray };
