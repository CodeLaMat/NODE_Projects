"use strict";

(function () {
  let numberField;
  let nameField;
  let ratingField;
  let yearField;
  let quantityField;
  let messagearea;
  let searchState = true;

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    numberField = document.getElementById("number");
    nameField = document.getElementById("name");
    ratingField = document.getElementById("rating");
    yearField = document.getElementById("year");
    quantityField = document.getElementById("quantity");
    messagearea = document.getElementById("messagearea");

    updateFields();

    document.getElementById("submit").addEventListener("click", send);

    numberField.addEventListener("focus", clearAll);
  }

  function updateMessage(message, type) {
    messagearea.textContent = message;
    messagearea.setAttribute("class", type);
  }

  function clearMessage() {
    messagearea.textContent = "";
    messagearea.removeAttribute("class");
  }

  function clearAll() {
    if (searchState) {
      clearFieldValues();
      clearMessage();
    }
  }

  function updateFields() {
    if (searchState) {
      numberField.removeAttribute("readonly");
      nameField.setAttribute("readonly", true);
      ratingField.setAttribute("readonly", true);
      yearField.setAttribute("readonly", true);
      quantityField.setAttribute("readonly", true);
    } else {
      numberField.setAttribute("readonly", true);
      nameField.removeAttribute("readonly");
      ratingField.removeAttribute("readonly");
      yearField.removeAttribute("readonly");
      quantityField.removeAttribute("readonly");
    }
  }

  function clearFieldValues() {
    numberField.value = "";
    nameField.value = "";
    ratingField.value = "";
    yearField.value = "";
    quantityField.value = "";
    searchState = true;
    updateFields();
  }

  function updateGame(result) {
    if (result.length === 0) return;
    const game = result[0];
    numberField.value = game.number;
    nameField.value = game.name;
    ratingField.value = game.rating;
    yearField.value = game.year;
    quantityField.value = game.quantity;
    searchState = false;
    updateFields();
  }

  async function send() {
    try {
      if (searchState) {
        if (numberField.value.trim().length > 0) {
          const data = await fetch(
            `http://localhost:4000/api/games/${numberField.value}`,
            { mode: "cors" }
          );
          const result = await data.json();
          if (result) {
            if (result.message) {
              updateMessage(result.message, result.type);
            } else {
              updateGame(result);
            }
          }
        }
      } else {
        const game = {
          number: numberField.value,
          name: nameField.value,
          rating: ratingField.value,
          year: yearField.value,
          quantity: quantityField.value,
        };

        const options = {
          method: "PUT",
          body: JSON.stringify(game),
          headers: {
            "Content-Type": "application/json",
          },
          mode: "cors",
        };

        const data = await fetch(
          `http://localhost:4000/api/games/${game.number}`,
          options
        );

        const status = await data.json();

        if (status.message) {
          updateMessage(status.message, status.type);
        }

        searchState = true;
        updateFields();
      }
    } catch (err) {
      updateMessage(err.message, "error");
    }
  }
})();
