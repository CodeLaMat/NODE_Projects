"use strict";

(function () {
  let resultarea;
  let messagearea;
  let gameNumber;

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    resultarea = document.getElementById("resultarea");
    gameNumber = document.getElementById("gamenumber");
    messagearea = document.getElementById("messagearea");
    document.getElementById("submit").addEventListener("click", send);
  }

  async function send() {
    clearMessage();
    resultarea.innerHTML = "";
    try {
      if (gameNumber.value.trim().length > 0) {
        const data = await fetch(
          `http://localhost:4000/api/games/${gameNumber.value}`,
          { mode: "cors" }
        );
        const result = await data.json();
        if (result) {
          if (result.message) {
            updateMessage(result.message, result.type);
          } else {
            updateGame(result);
          }
        }
      }
    } catch (error) {
      updateMessage(`Not found. ${error.message}`, "error");
    }
  }

  function updateMessage(message, type) {
    messagearea.textContent = message;
    messagearea.setAttribute("class", type);
  }

  function clearMessage() {
    messagearea.textContent = "";
    messagearea.removeAttribute("class");
  }

  function updateGame(result) {
    if (result.length === 0) return;
    const game = result[0];
    resultarea.innerHTML = `
        <p><span class="legend">Number: </span> ${game.number}</p>
        <p><span class="legend">Name: </span> ${game.name}</p>
        <p><span class="legend">Rating: </span> ${game.rating}</p>
        <p><span class="legend">Year: </span> ${game.year}</p>
        <p><span class="legend">Quantity: </span> ${game.quantity}</p>
        `;
  }
})();
